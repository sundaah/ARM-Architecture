#include "device_driver.h"
#include <stdlib.h>

#define LCDW             320
#define LCDH             240
#define X_MIN             0
#define X_MAX             (LCDW - 1)
#define Y_MIN             0
#define Y_MAX             (LCDH - 1)

#define TIMER_PERIOD      10
#define RIGHT             1
#define LEFT              -1
#define FORWARD           -1 // Y축 감소 (위로 이동)
#define BACKWARD          1  // Y축 증가 (아래로 이동)

#define OBSTACLE_STEP     10
#define OBSTACLE_SIZE_X   20
#define OBSTACLE_SIZE_Y   20
#define PLANE_STEP        10
#define PLANE_SIZE_X      20
#define PLANE_SIZE_Y      20

#define BACK_COLOR        5
#define OBSTACLE_COLOR    0
#define PLANE_COLOR       1

#define GAME_OVER         1
#define MAX_OBSTACLES     10 // 장애물 수 증가

typedef struct {
    int x, y;
    int w, h;
    int ci;
    int dir;
} QUERY_DRAW;

static QUERY_DRAW obstacles[MAX_OBSTACLES];
static QUERY_DRAW plane;

static int score;
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

static void Draw_Object(QUERY_DRAW *obj) {
    Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}

static int Check_Collision(QUERY_DRAW *a, QUERY_DRAW *b) {
    if (a->x < b->x + b->w && a->x + a->w > b->x &&
        a->y < b->y + b->h && a->y + a->h > b->y) {
        return 1;
    }
    return 0;
}

static int Check_All_Collisions(void) {
    int i;
    for (i = 0; i < MAX_OBSTACLES; i++) {
        if (Check_Collision(&plane, &obstacles[i])) {
            Uart_Printf("SCORE = %d\n", score);
            return GAME_OVER;
        }
    }

    if (plane.y <= Y_MIN) {
        score++;
        Uart_Printf("SCORE: %d\n", score);
        Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score);
        plane.y = Y_MAX - plane.h;
    }

    return 0;
}

static int Obstacle_Move(void) {
    int i;
    for (i = 0; i < MAX_OBSTACLES; i++) {
        obstacles[i].ci = BACK_COLOR;
        Draw_Object(&obstacles[i]);

        obstacles[i].y += OBSTACLE_STEP;
        if (obstacles[i].y > Y_MAX) {
            obstacles[i].y = Y_MIN - (rand() % (LCDH / 2)); // 화면 위에서 랜덤한 위치부터 다시 시작
            obstacles[i].x = rand() % (LCDW - OBSTACLE_SIZE_X);
        }

        obstacles[i].ci = OBSTACLE_COLOR;
        Draw_Object(&obstacles[i]);
    }

    return Check_All_Collisions();
}

static void k0(void) { // 위로 이동 (앞으로)
    if (plane.y > Y_MIN) plane.y -= PLANE_STEP;
}

static void k1(void) { // 아래로 이동 (뒤로)
    if (plane.y + plane.h < Y_MAX) plane.y += PLANE_STEP;
}

static void k2(void) { // 왼쪽으로 이동
    if (plane.x > X_MIN) plane.x -= PLANE_STEP;
}

static void k3(void) { // 오른쪽으로 이동
    if (plane.x + plane.w < X_MAX) plane.x += PLANE_STEP;
}

static int Plane_Move(int k) {
    static void (*key_func[])(void) = {k0, k1, k2, k3};
    if (k <= 3 && key_func[k] != NULL) key_func[k]();
    return Check_All_Collisions();
}

static void Game_Init(void) {
    int i;
    score = 0;
    Lcd_Clr_Screen();
    Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score); // 초기 점수 표시

    plane.x = 150;
    plane.y = Y_MAX - PLANE_SIZE_Y;
    plane.w = PLANE_SIZE_X;
    plane.h = PLANE_SIZE_Y;
    plane.ci = PLANE_COLOR;
    plane.dir = 0;
    Draw_Object(&plane);

    for (i = 0; i < MAX_OBSTACLES; i++) {
        obstacles[i].x = rand() % (LCDW - OBSTACLE_SIZE_X);
        obstacles[i].y = rand() % (LCDH / 2);
        obstacles[i].w = OBSTACLE_SIZE_X;
        obstacles[i].h = OBSTACLE_SIZE_Y;
        obstacles[i].ci = OBSTACLE_COLOR;
        obstacles[i].dir = 0;
        Draw_Object(&obstacles[i]);
    }
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void System_Init(void) {
    Clock_Init();
    LED_Init();
    Key_Poll_Init();
    Uart1_Init(115200);

    SCB->VTOR = 0x08003000;
    SCB->SHCSR = 7 << 16;
}

#define DISPLAY_MODE    3

void Main(void) {
    System_Init();
    Uart_Printf("Plane Game\n");

    Lcd_Init(DISPLAY_MODE);

    Jog_Poll_Init();
    Jog_ISR_Enable(1);
    Uart1_RX_Interrupt_Enable(1);

    for (;;) {
        Game_Init();
        TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);

        for (;;) {
            int game_over = 0;

            if (Jog_key_in) {
                plane.ci = BACK_COLOR;
                Draw_Object(&plane);
                game_over = Plane_Move(Jog_key);
                plane.ci = PLANE_COLOR;
                Draw_Object(&plane);
                Jog_key_in = 0;
            }

            if (TIM4_expired) {
                game_over = Obstacle_Move();
                TIM4_expired = 0;
            }

            if (game_over) {
                TIM4_Repeat_Interrupt_Enable(0, 0);
                Uart_Printf("Game Over, Please press any key to continue.\n");
                Jog_Wait_Key_Pressed();
                Jog_Wait_Key_Released();
                Uart_Printf("Game Start\n");
                break;
            }
        }
    }
}