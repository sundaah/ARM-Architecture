#if 0

#include "device_driver.h"

#define LCDW			(320)
#define LCDH			(240)
#define X_MIN	 		(0)
#define X_MAX	 		(LCDW - 1)
#define Y_MIN	 		(0)
#define Y_MAX	 		(LCDH - 1)

#define TIMER_PERIOD	(10)
#define RIGHT			(1)
#define LEFT			(-1)
#define HOME			(0)
#define SCHOOL			(1)

#define CAR_STEP		(10)
#define CAR_SIZE_X		(20)
#define CAR_SIZE_Y		(20)
#define FROG_STEP		(10)
#define FROG_SIZE_X		(20)
#define FROG_SIZE_Y		(20)

#define BACK_COLOR		(5)
#define CAR_COLOR		(0)
#define FROG_COLOR		(1)

#define GAME_OVER		(1)

typedef struct
{
	int x,y;
	int w,h;
	int ci;
	int dir;
}QUERY_DRAW;

static QUERY_DRAW car;
static QUERY_DRAW frog;

static int score;
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

static int Check_Collision(void)
{
	int col = 0;

	if((car.x >= frog.x) && ((frog.x + FROG_STEP) >= car.x)) col |= 1<<0;
	else if((car.x < frog.x) && ((car.x + CAR_STEP) >= frog.x)) col |= 1<<0;
	
	if((car.y >= frog.y) && ((frog.y + FROG_STEP) >= car.y)) col |= 1<<1;
	else if((car.y < frog.y) && ((car.y + CAR_STEP) >= frog.y)) col |= 1<<1;

	if(col == 3)
	{
		Uart_Printf("SCORE = %d\n", score);	
		return GAME_OVER;
	}

	if((frog.dir == SCHOOL) && (frog.y == Y_MIN)) 
	{
		Uart_Printf("SCHOOL\n");		
		frog.dir = HOME;
	}

	if((frog.dir == HOME) && (frog.y == LCDH - frog.h))
	{
		frog.dir = SCHOOL;
		score++;
		Uart_Printf("HOME, %d\n", score);
		Lcd_Printf(0,0,BLUE,WHITE,2,2,"%d", score);
	}

	return 0;
}

static int Car_Move(void)
{
	car.x += CAR_STEP * car.dir;
	if((car.x + car.w >= X_MAX) || (car.x <= X_MIN)) car.dir = -car.dir;
	return Check_Collision();
}

static void k0(void)
{
	if(frog.y > Y_MIN) frog.y -= FROG_STEP;
}

static void k1(void)
{
	if(frog.y + frog.h < Y_MAX) frog.y += FROG_STEP;
}

static void k2(void)
{
	if(frog.x > X_MIN) frog.x -= FROG_STEP;
}

static void k3(void)
{
	if(frog.x + frog.w < X_MAX) frog.x += FROG_STEP;
}

static int Frog_Move(int k)
{
	// UP(0), DOWN(1), LEFT(2), RIGHT(3)
	static void (*key_func[])(void) = {k0, k1, k2, k3};
	if(k <= 3) key_func[k]();
	return Check_Collision();
}

static void Game_Init(void)
{
	score = 0;
	Lcd_Clr_Screen();
	frog.x = 150; frog.y = 220; frog.w = FROG_SIZE_X; frog.h = FROG_SIZE_Y; frog.ci = FROG_COLOR; frog.dir = SCHOOL;
	car.x = 0; car.y = 110; car.w = CAR_SIZE_X; car.h = CAR_SIZE_Y; car.ci = CAR_COLOR; car.dir = RIGHT;
	Lcd_Draw_Box(frog.x, frog.y, frog.w, frog.h, color[frog.ci]);
	Lcd_Draw_Box(car.x, car.y, car.w, car.h, color[car.ci]);
}

static void Draw_Object(QUERY_DRAW * obj)
{
	Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void System_Init(void)
{
	Clock_Init();
	LED_Init();
	Key_Poll_Init();
	Uart1_Init(115200);

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 7<<16;
}

#define DIPLAY_MODE		3

void Main(void)
{
	System_Init();
	Uart_Printf("Street Froggy\n");

	Lcd_Init(DIPLAY_MODE);

	Jog_Poll_Init();
	Jog_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);

	for(;;)
	{
		Game_Init();
		TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD*10);
		Lcd_Printf(0,0,BLUE,WHITE,2,2,"%d", score);

		for(;;)
		{
			int game_over = 0;

			if(Jog_key_in) 
			{
				frog.ci = BACK_COLOR;
				Draw_Object(&frog);
				game_over = Frog_Move(Jog_key);
				frog.ci = FROG_COLOR;
				Draw_Object(&frog);
				Jog_key_in = 0;
			}

			if(TIM4_expired) 
			{
				car.ci = BACK_COLOR;
				Draw_Object(&car);
				game_over = Car_Move();
				car.ci = CAR_COLOR;
				Draw_Object(&car);
				TIM4_expired = 0;
			}

			if(game_over)
			{
				TIM4_Repeat_Interrupt_Enable(0, 0);
				Uart_Printf("Game Over, Please press any key to continue.\n");
				Jog_Wait_Key_Pressed();
				Jog_Wait_Key_Released();
				Uart_Printf("Game Start\n");
				break;
			}
		}
	}
}

#endif

#if 0

#include "device_driver.h"
#include <stdlib.h>
#include <stddef.h>

#define LCDW            (320)
#define LCDH            (240)
#define X_MIN           (0)
#define X_MAX           (LCDW - 1)
#define Y_MIN           (0)
#define Y_MAX           (LCDH - 1)

#define TIMER_PERIOD    (10)
#define RIGHT           (1)
#define LEFT            (-1)

#define PLAYER_STEP     (10)
#define PLAYER_SIZE_X   (20)
#define PLAYER_SIZE_Y   (20)
#define POOP_STEP       (10)
#define POOP_SIZE_X     (20)
#define POOP_SIZE_Y     (20)

#define BACK_COLOR      (5)
#define POOP_COLOR      (0)
#define PLAYER_COLOR    (1)

#define GAME_OVER       (1)

typedef struct
{
    int x, y;
    int w, h;
    int ci;
    int dir;
} QUERY_DRAW;

static QUERY_DRAW poop;
static QUERY_DRAW player;

static int score;
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

static int Check_Collision(void)
{
    int col = 0;

    if ((poop.x >= player.x) && ((player.x + PLAYER_STEP) >= poop.x)) col |= 1 << 0;
    else if ((poop.x < player.x) && ((poop.x + POOP_STEP) >= player.x)) col |= 1 << 0;

    if ((poop.y >= player.y) && ((player.y + PLAYER_STEP) >= poop.y)) col |= 1 << 1;
    else if ((poop.y < player.y) && ((poop.y + POOP_STEP) >= player.y)) col |= 1 << 1;

    if (col == 3)
    {
        Uart_Printf("SCORE = %d\n", score);
        return GAME_OVER;
    }

    if (poop.y >= Y_MAX)
    {
        poop.y = 0;
        poop.x = (rand() % (LCDW - POOP_SIZE_X));
        score++;
        Uart_Printf("SCORE = %d\n", score);
        Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score);
    }

    return 0;
}

static int Poop_Move(void)
{
    poop.y += POOP_STEP;
    return Check_Collision();
}

static void k2(void)
{
    if (player.x > X_MIN) player.x -= PLAYER_STEP;
}

static void k3(void)
{
    if (player.x + player.w < X_MAX) player.x += PLAYER_STEP;
}

static int Player_Move(int k)
{
    // LEFT(2), RIGHT(3)
    static void (*key_func[])(void) = {NULL, NULL, k2, k3};
    if (k <= 3 && key_func[k] != NULL) key_func[k]();
    return Check_Collision();
}

static void Draw_Object(QUERY_DRAW *obj)
{
    Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}

static void Game_Init(void)
{
    score = 0;
    Lcd_Clr_Screen();
    player.x = 150; player.y = 220; player.w = PLAYER_SIZE_X; player.h = PLAYER_SIZE_Y; player.ci = PLAYER_COLOR; player.dir = 0;
    poop.x = rand() % (LCDW - POOP_SIZE_X); poop.y = 0; poop.w = POOP_SIZE_X; poop.h = POOP_SIZE_Y; poop.ci = POOP_COLOR; poop.dir = 0;
    Draw_Object(&player);
    Draw_Object(&poop);
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void System_Init(void)
{
    Clock_Init();
    LED_Init();
    Key_Poll_Init();
    Uart1_Init(115200);

    SCB->VTOR = 0x08003000;
    SCB->SHCSR = 7 << 16;
}

#define DISPLAY_MODE    3

void Main(void)
{
    System_Init();
    Uart_Printf("Poop Dodging Game\n");

    Lcd_Init(DISPLAY_MODE);

    Jog_Poll_Init();
    Jog_ISR_Enable(1);
    Uart1_RX_Interrupt_Enable(1);

    for (;;)
    {
        Game_Init();
        TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);
        Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score);

        for (;;)
        {
            int game_over = 0;

            if (Jog_key_in)
            {
                player.ci = BACK_COLOR;
                Draw_Object(&player);
                game_over = Player_Move(Jog_key);
                player.ci = PLAYER_COLOR;
                Draw_Object(&player);
                Jog_key_in = 0;
            }

            if (TIM4_expired)
            {
                poop.ci = BACK_COLOR;
                Draw_Object(&poop);
                game_over = Poop_Move();
                poop.ci = POOP_COLOR;
                Draw_Object(&poop);
                TIM4_expired = 0;
            }

            if (game_over)
            {
                TIM4_Repeat_Interrupt_Enable(0, 0);
                Uart_Printf("Game Over, Please press any key to continue.\n");
                Jog_Wait_Key_Pressed();
                Jog_Wait_Key_Released();
                Uart_Printf("Game Start\n");
                break;
            }
        }
    }
}
#endif

#if 1

#include "device_driver.h"
#include <stdlib.h> // rand 함수 사용을 위해 추가


#define LCDW            320
#define LCDH            240
#define X_MIN           0
#define X_MAX           (LCDW - 1)
#define Y_MIN           0
#define Y_MAX           (LCDH - 1)

#define TIMER_PERIOD    10
#define RIGHT           1
#define LEFT            -1

#define OBSTACLE_STEP   10
#define OBSTACLE_SIZE_X 20
#define OBSTACLE_SIZE_Y 20
#define PLANE_STEP      10
#define PLANE_SIZE_X    20
#define PLANE_SIZE_Y    20

#define BACK_COLOR      5
#define OBSTACLE_COLOR  0
#define PLANE_COLOR     1

#define GAME_OVER       1

typedef struct
{
    int x, y;
    int w, h;
    int ci;
    int dir;
} QUERY_DRAW;



static QUERY_DRAW obstacle;
static QUERY_DRAW plane;

static int score;
static unsigned short color[] = {RED, YELLOW, GREEN, BLUE, WHITE, BLACK};

static int Check_Collision(void)
{
    int col = 0;

    if ((obstacle.x >= plane.x) && ((plane.x + PLANE_STEP) >= obstacle.x)) col |= 1 << 0;
    else if ((obstacle.x < plane.x) && ((obstacle.x + OBSTACLE_STEP) >= plane.x)) col |= 1 << 0;

    if ((obstacle.y >= plane.y) && ((plane.y + PLANE_STEP) >= obstacle.y)) col |= 1 << 1;
    else if ((obstacle.y < plane.y) && ((obstacle.y + OBSTACLE_STEP) >= plane.y)) col |= 1 << 1;

    if (col == 3)
    {
        Uart_Printf("SCORE = %d\n", score);
        return GAME_OVER;
    }

    if (plane.y == Y_MIN)
    {
        Uart_Printf("TOP\n");
        score++;
        Uart_Printf("SCORE: %d\n", score);
        Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score);
    }

    return 0;
}

static int Obstacle_Move(void)
{
    obstacle.y += OBSTACLE_STEP;
    if (obstacle.y > Y_MAX)
    {
        obstacle.y = Y_MIN;
        obstacle.x = (rand() % (LCDW - OBSTACLE_SIZE_X));
    }
    return Check_Collision();
}

static void k2(void)
{
    if (plane.x > X_MIN) plane.x -= PLANE_STEP;
}

static void k3(void)
{
    if (plane.x + plane.w < X_MAX) plane.x += PLANE_STEP;
}

static int Plane_Move(int k)
{
    // LEFT(2), RIGHT(3)
    static void (*key_func[])(void) = {NULL, NULL, k2, k3};
    if (k <= 3 && key_func[k] != NULL) key_func[k]();
    return Check_Collision();
}

static void Draw_Object(QUERY_DRAW *obj)
{
    Lcd_Draw_Box(obj->x, obj->y, obj->w, obj->h, color[obj->ci]);
}

static void Game_Init(void)
{
    score = 0;
    Lcd_Clr_Screen();
    plane.x = 150; plane.y = 220; plane.w = PLANE_SIZE_X; plane.h = PLANE_SIZE_Y; plane.ci = PLANE_COLOR; plane.dir = 0;
    obstacle.x = rand() % (LCDW - OBSTACLE_SIZE_X); obstacle.y = 0; obstacle.w = OBSTACLE_SIZE_X; obstacle.h = OBSTACLE_SIZE_Y; obstacle.ci = OBSTACLE_COLOR; obstacle.dir = 0;
    Draw_Object(&plane);
    Draw_Object(&obstacle);
}

extern volatile int TIM4_expired;
extern volatile int USART1_rx_ready;
extern volatile int USART1_rx_data;
extern volatile int Jog_key_in;
extern volatile int Jog_key;

void System_Init(void)
{
    Clock_Init();
    LED_Init();
    Key_Poll_Init();
    Uart1_Init(115200);

    SCB->VTOR = 0x08003000;
    SCB->SHCSR = 7 << 16;
}

#define DISPLAY_MODE    3

void Main(void)
{
    System_Init();
    Uart_Printf("Plane Game\n");

    Lcd_Init(DISPLAY_MODE);

    Jog_Poll_Init();
    Jog_ISR_Enable(1);
    Uart1_RX_Interrupt_Enable(1);

    for (;;)
    {
        Game_Init();
        TIM4_Repeat_Interrupt_Enable(1, TIMER_PERIOD * 10);
        Lcd_Printf(0, 0, BLUE, WHITE, 2, 2, "%d", score);

        for (;;)
        {
            int game_over = 0;

            if (Jog_key_in)
            {
                plane.ci = BACK_COLOR;
                Draw_Object(&plane);
                game_over = Plane_Move(Jog_key);
                plane.ci = PLANE_COLOR;
                Draw_Object(&plane);
                Jog_key_in = 0;
            }

            if (TIM4_expired)
            {
                obstacle.ci = BACK_COLOR;
                Draw_Object(&obstacle);
                game_over = Obstacle_Move();
                obstacle.ci = OBSTACLE_COLOR;
                Draw_Object(&obstacle);
                TIM4_expired = 0;
            }

            if (game_over)
            {
                TIM4_Repeat_Interrupt_Enable(0, 0);
                Uart_Printf("Game Over, Please press any key to continue.\n");
                Jog_Wait_Key_Pressed();
                Jog_Wait_Key_Released();
                Uart_Printf("Game Start\n");
                break;
            }
        }
    }
}

#endif